import logging

import time

from vdk.api.job_input  import IJobInput

log = logging.getLogger(__name__)


def run(job_input: IJobInput):
    """
    Function named `run` is required in order for a python script to be recognized as a Data Job Python step and executed.

    VDK provides to every python step an object - job_input - that has methods for:

    * executing queries to OLAP Database.
    * ingesting data into Data Lake
    * processing Data Lake data into a dimensional model Data Warehouse.
    See IJobInput documentation
    """
    with open("test-file.txt", 'w') as f:
        f.write("Testing sentence.")

    with open("test-file.txt", 'r') as f:
        if str(f.read()) != 'Testing sentence.':
            raise Exception("File write was unsuccessful.")
