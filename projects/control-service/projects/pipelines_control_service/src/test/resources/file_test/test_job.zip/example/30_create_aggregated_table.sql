CREATE TABLE IF NOT EXISTS super_collider.example_aggregated_table(
   vc_id STRING,
   esx_count INT,
   vm_count INT
) STORED AS PARQUET;
