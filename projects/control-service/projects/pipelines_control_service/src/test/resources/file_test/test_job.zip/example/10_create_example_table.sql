CREATE TABLE IF NOT EXISTS super_collider.example_table(
   vc_id STRING,
   esx_id STRING,
   vm_count INT
) STORED AS PARQUET;