TRUNCATE TABLE IF EXISTS super_collider.example_aggregated_table;
